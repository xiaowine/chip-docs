@echo off

cd /d %~dp0

cd server

start javaw -Djava.library.path=../../lib/ -jar PDE_server.jar
cd..

start javaw -Djava.library.path=../lib/ -jar PDE_client.jar